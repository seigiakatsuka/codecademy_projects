export const Loader = () => {
  return <div className='lds-dual-ring'></div>;
};
